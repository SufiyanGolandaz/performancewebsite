import React from "react";
import appstyles from '../css/pages.module.css'

function Partners() {
  return <div className={appstyles.padtop}>Partners</div>;
}

export default Partners;
