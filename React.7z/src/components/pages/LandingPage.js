import React from "react";
import classes from "../css/LandingPage.module.css";

function LandingPage() {
  return <div className={classes.body}></div>;
}

export default LandingPage;
