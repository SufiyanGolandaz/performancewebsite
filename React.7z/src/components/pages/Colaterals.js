import React from "react";
import classes from "../css/pages.module.css";

function Colaterals() {
  return <div className={classes.padtop}>Colaterals</div>;
}

export default Colaterals;
