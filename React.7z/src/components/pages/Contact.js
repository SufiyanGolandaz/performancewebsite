import React from "react";
import classes from "../css/pages.module.css";

function Contact() {
  return (
    <div className={classes.padtop}>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Aut quibusdam
      sapiente qui possimus ex ratione nesciunt optio. Aliquid, ipsa
      consequatur! Dicta enim corporis repellendus qui porro obcaecati excepturi
      placeat eius.
    </div>
  );
}

export default Contact;
